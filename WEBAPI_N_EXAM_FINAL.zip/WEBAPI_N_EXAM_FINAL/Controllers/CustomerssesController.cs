﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WEBAPI_N_EXAM_FINAL.Models;

namespace WEBAPI_N_EXAM_FINAL.Controllers
{
    public class CustomerssesController : ApiController
    {
        private Sep19CHNEntities db = new Sep19CHNEntities();

        // GET: api/Customersses
        public IQueryable<Customerss> GetCustomersses()
        {
            return db.Customersses;
        }

        // GET: api/Customersses/5
        [ResponseType(typeof(Customerss))]
        public IHttpActionResult GetCustomerss(int id)
        {
            Customerss customerss = db.Customersses.Find(id);
            if (customerss == null)
            {
                return NotFound();
            }

            return Ok(customerss);
        }

        // PUT: api/Customersses/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCustomerss(int id, Customerss customerss)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != customerss.CustomerID)
            {
                return BadRequest();
            }

            db.Entry(customerss).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerssExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Customersses
        [ResponseType(typeof(Customerss))]
        public IHttpActionResult PostCustomerss(Customerss customerss)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Customersses.Add(customerss);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (CustomerssExists(customerss.CustomerID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = customerss.CustomerID }, customerss);
        }

        // DELETE: api/Customersses/5
        [ResponseType(typeof(Customerss))]
        public IHttpActionResult DeleteCustomerss(int id)
        {
            Customerss customerss = db.Customersses.Find(id);
            if (customerss == null)
            {
                return NotFound();
            }

            db.Customersses.Remove(customerss);
            db.SaveChanges();

            return Ok(customerss);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CustomerssExists(int id)
        {
            return db.Customersses.Count(e => e.CustomerID == id) > 0;
        }
    }
}